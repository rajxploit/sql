
# RAJMAP — Savage SQLMap Fork

## 💣 Mode Penggunaan BRUTAL
1. Jalankan dengan:
   ```bash
   python3 rajmap.py --brutal
   ```

2. Masukkan target URL manual saat dijalankan:
   ```
   💡 Contoh:
   http://target.com/index.php?id=1
   ```

3. Fitur yang aktif otomatis saat --brutal:
   - 🎭 User-Agent Faker
   - 🔂 Auto Retry Brutalizer
   - ☁️ Cloudflare Dodger
   - 💉 Savage Injection Mode
   - 🧪 Payload Fuzzer
   - 💻 CLI Dashboard (Rich)

4. Hasil dump otomatis disimpan di folder:
   ```
   output/
   ```

## 🔧 Header bisa dikustomisasi di:
```
config/headers.txt
```

## 🧠 Payload tambahan tersedia di:
```
config/payloads.txt
```
